# Skip Ad Tester V2

تطبيق Android تجريبي لاكتشاف أزرار Skip/Close.

## بناء APK من الهاتف فقط باستخدام GitHub Actions

1. أنشئ حساباً في GitHub من الهاتف.
2. أنشئ Repository جديداً باسم `SkipAdTester`.
3. ارفع محتويات هذا المشروع إلى الـRepository (يجب أن يكون `app` و`build.gradle.kts` و`settings.gradle.kts` في جذر المستودع).
4. مجلد `.github/workflows` الموجود في هذا المشروع يحتوي على ملف `build-apk.yml`.
5. افتح تبويب Actions في المستودع وشغّل `Build Android APK`.
6. بعد نجاح البناء، افتح صفحة الـworkflow ثم قسم Artifacts وحمّل `SkipAdTester-debug-apk`.
7. فك ضغط ملف الـartifact لتحصل على `app-debug.apk` ثم ثبّته على الهاتف.

الـworkflow يستخدم Java 17 وAndroid SDK وGradle 8.10 ويبني Debug APK.
