package com.example.skipadtester

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity

class MainActivity : android.app.Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
        }

        val title = TextView(this).apply {
            text = "Skip Ad Tester"
            textSize = 28f
            gravity = Gravity.CENTER
        }

        val info = TextView(this).apply {
            text = "\n1. اضغط الزر أدناه.\n2. فعّل Skip Ad Tester من خدمات إمكانية الوصول.\n3. افتح تطبيقاً يحتوي على إعلان قابل للتخطي.\n\nالنسخة التجريبية تبحث عن Skip / تخطي / Close / إغلاق / ×."
            textSize = 16f
        }

        val button = Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        layout.addView(title)
        layout.addView(info)
        layout.addView(button)
        setContentView(layout)
    }
}
