package com.example.skipadtester.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo

class AdAccessibilityService : AccessibilityService() {

    private var lastAction = 0L

    private val textTargets = listOf(
        "skip", "close", "dismiss", "continue",
        "تخطي", "إغلاق", "اغلاق", "إقفال", "إخفاء"
    )

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {
        if (event == null) return

        val now = SystemClock.uptimeMillis()
        if (now - lastAction < 1500) return

        val root = rootInActiveWindow ?: return

        // 1) First look for explicit Skip/Close text or content descriptions.
        findTextTarget(root)?.let {
            if (clickNodeOrParent(it)) {
                lastAction = now
                return
            }
        }

        // 2) Then look for likely close buttons based on accessibility metadata,
        // size, position, and short symbols such as × or X.
        findLikelyCloseButton(root)?.let {
            if (clickNodeOrParent(it)) {
                lastAction = now
            }
        }
    }

    private fun findTextTarget(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)

        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            val value = ((n.text?.toString() ?: "") + " " +
                    (n.contentDescription?.toString() ?: "")).trim().lowercase()

            if (value.isNotEmpty() &&
                textTargets.any { value == it || value.contains(it) } &&
                n.isVisibleToUser) {
                return n
            }

            for (i in 0 until n.childCount) {
                n.getChild(i)?.let(queue::add)
            }
        }
        return null
    }

    private fun findLikelyCloseButton(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        val screen = Rect()
        root.getBoundsInScreen(screen)

        var best: AccessibilityNodeInfo? = null
        var bestScore = Int.MIN_VALUE

        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()

            if (n.isVisibleToUser && (n.isClickable || n.isFocusable)) {
                val r = Rect()
                n.getBoundsInScreen(r)
                val w = r.width()
                val h = r.height()

                if (w in 20..220 && h in 20..220) {
                    val text = ((n.text?.toString() ?: "") + " " +
                            (n.contentDescription?.toString() ?: "")).lowercase()

                    var score = 0

                    // Common close symbols/labels.
                    if (text.contains("×") || text == "x" || text.contains("close") ||
                        text.contains("dismiss") || text.contains("إغلاق") ||
                        text.contains("اغلاق")) score += 100

                    // Small, roughly square controls are common close-button shapes.
                    val ratio = w.toFloat() / h.toFloat()
                    if (ratio in 0.65f..1.5f) score += 15

                    // Close buttons are often near a screen corner.
                    val nearRight = r.centerX() > screen.right * 0.75f
                    val nearTop = r.centerY() < screen.bottom * 0.30f
                    if (nearRight && nearTop) score += 35

                    // Avoid obvious large controls.
                    if (w > screen.width() * 0.35 || h > screen.height() * 0.20) score -= 80

                    if (score > bestScore) {
                        bestScore = score
                        best = n
                    }
                }
            }

            for (i in 0 until n.childCount) {
                n.getChild(i)?.let(queue::add)
            }
        }

        // Require a meaningful confidence score before clicking.
        return if (bestScore >= 35) best else null
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        if (node.isVisibleToUser && node.isClickable &&
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true

        var p = node.parent
        repeat(3) {
            if (p != null) {
                if (p.isVisibleToUser && p.isClickable &&
                    p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                p = p.parent
            }
        }
        return false
    }

    override fun onInterrupt() {}
}
